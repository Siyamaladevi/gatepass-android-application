package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.gatepasssystem.Adapter.HodResAdapter;
import com.example.gatepasssystem.Adapter.StaffHodAdapter;
import com.example.gatepasssystem.Modal.HodResponse;
import com.example.gatepasssystem.Modal.StaffHodRequest;

import java.util.ArrayList;

public class StaffFinalList extends AppCompatActivity {

    ListView listView;

    MainDB db;
    StaffHodRequest staffHodRequest;
    StaffHodAdapter ad;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_final_list);
        listView=findViewById(R.id.list);

        db = new MainDB(this);
        ShowList();


    }
    private void ShowList(){
        final ArrayList<StaffHodRequest> data = new ArrayList<>(db.getv());
        ad = new StaffHodAdapter(data,db,this);

        listView.setAdapter(ad);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                staffHodRequest = data.get(i);
            }
        });
    }
}