package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.gatepasssystem.Modal.HodResponse;
import com.example.gatepasssystem.Modal.StaffPrincipalRes;

public class StafftoPrin extends AppCompatActivity {
    EditText com;
    String Apr[] = {"Request Status", "Approved", "Not Approved"};
    String apv, Name, Date, ID,number;
    Button sub;
    MainDB db;
    Spinner approval;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staffto_prin);
        com = findViewById(R.id.com);
        approval = findViewById(R.id.apr);
        sub = findViewById(R.id.sub);
        db = new MainDB(this);
        getSpinner1();
        getval1();
        SharedPreferences staffsign=getSharedPreferences("staffKey",MODE_PRIVATE);
        number=staffsign.getString("mob","");

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Comment = com.getText().toString();
                if (Comment.isEmpty()) {
                    Toast.makeText(StafftoPrin.this, "Enter Comment", Toast.LENGTH_SHORT).show();
                } else {
                    if (apv.equals("Approved")) {
                        Boolean checkData = db.insertStaffPrinRes(new StaffPrincipalRes(Name, ID, Date));
                        if (checkData == true) {
                            Toast.makeText(StafftoPrin.this, "Submitted Successfully!", Toast.LENGTH_SHORT).show();
                            alert();
                        } else {
                            Toast.makeText(StafftoPrin.this, "Failed", Toast.LENGTH_SHORT).show();
                        }
                    } else if (apv.equals("Not Approved")) {
                        Toast.makeText(StafftoPrin.this, "Staff denied the Gate Pass", Toast.LENGTH_SHORT).show();
                        alert2();
                    }

                }
            }
        });
    }

    public void getSpinner1() {
        ArrayAdapter appArr = new ArrayAdapter<>(StafftoPrin.this, android.R.layout.simple_spinner_item, Apr);
        appArr.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        approval.setAdapter(appArr);

        approval.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                apv = approval.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void getval1() {
        Intent i = getIntent();
        Name = i.getStringExtra("name");
        ID = i.getStringExtra("id");
        Date = i.getStringExtra("date");
    }
    private void alert(){
        String content="Your requesting pass has been approved";
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(number, null, content, null, null);
            Toast.makeText(getApplicationContext(),"Sent",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage().toString(),Toast.LENGTH_SHORT).show();
        }
    }
    private void alert2(){
        String content="Your requesting pass has been denied";
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(number, null, content, null, null);
            Toast.makeText(getApplicationContext(),"Sent",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage().toString(),Toast.LENGTH_SHORT).show();
        }
    }
}
