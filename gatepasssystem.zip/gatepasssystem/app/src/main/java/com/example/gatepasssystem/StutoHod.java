package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.gatepasssystem.Modal.HodResponse;
import com.example.gatepasssystem.Modal.StaffResponse;

public class StutoHod extends AppCompatActivity {
    EditText com;
    String Apr[]={"Request Status","Approved","Not Approved"};
    String apv,name,regNo,dept,branch,date,Stu_number,p_number;
    Button sub;
    MainDB db;
    Spinner approval;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stuto_hod);
        com = findViewById(R.id.com);
        approval = findViewById(R.id.apr);
        sub = findViewById(R.id.sub);
        db = new MainDB(this);
        getValues();
        getSpinnerValues();

        SharedPreferences studSign=getSharedPreferences("studKey",MODE_PRIVATE);
        Stu_number=studSign.getString("mob","");
        p_number=studSign.getString("pnm","");


        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Comment = com.getText().toString();
                if (Comment.isEmpty()) {
                    Toast.makeText(StutoHod.this, "Enter Comment", Toast.LENGTH_SHORT).show();
                } else {
                    if (apv.equals("Approved")) {
                        Boolean checkData = db.insertHodRes(new HodResponse(name,regNo,dept,branch,date));
                        if (checkData == true) {
                            Toast.makeText(StutoHod.this, "Submitted Successfully!", Toast.LENGTH_SHORT).show();
                            Success();
                            parent();
                        } else {
                            Toast.makeText(StutoHod.this, "Failed", Toast.LENGTH_SHORT).show();
                        }
                    } else if (apv.equals("Not Approved")) {
                        Toast.makeText(StutoHod.this, "Staff denied the Gate Pass", Toast.LENGTH_SHORT).show();
                        mes();
                    }

                }

            }
        });
    }
    public void getSpinnerValues() {
        ArrayAdapter appArr = new ArrayAdapter<>(StutoHod.this, android.R.layout.simple_spinner_item, Apr);
        appArr.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        approval.setAdapter(appArr);

        approval.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                apv = approval.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    public void getValues(){
        Intent i = getIntent();
        name = i.getStringExtra("name");
        regNo=i.getStringExtra("regNo");
        dept=i.getStringExtra("dept");
        branch=i.getStringExtra("branch");
        date=i.getStringExtra("date");

    }
    private void Success(){
        String content="Your requesting pass has been approved";
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(Stu_number, null, content, null, null);
            Toast.makeText(getApplicationContext(),"Sent",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage().toString(),Toast.LENGTH_SHORT).show();
        }
    }
    private void parent(){
        String content="Your son/daughter has get an gatepass";
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(p_number, null, content, null, null);
            Toast.makeText(getApplicationContext(),"Sent",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage().toString(),Toast.LENGTH_SHORT).show();
        }
    }
    private void mes(){
        String content="Your requesting pass has been denied";
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(Stu_number, null, content, null, null);
            Toast.makeText(getApplicationContext(),"Sent",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage().toString(),Toast.LENGTH_SHORT).show();
        }
    }
}