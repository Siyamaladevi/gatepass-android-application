package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class HodDashboard extends AppCompatActivity {
    CardView stuDetails,staffReq,gatereq;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hod_dashboard);
        stuDetails=findViewById(R.id.studet);
        staffReq=findViewById(R.id.staffdet);
        gatereq=findViewById(R.id.hodreq);
        stuDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(HodDashboard.this,StafftoHodlist.class);
                startActivity(intent);
            }
        });
        staffReq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(HodDashboard.this,StaffReqList.class);
                startActivity(i);
            }
        });
        gatereq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(HodDashboard.this,HodReq.class);
                startActivity(i);
                
            }
        });

    }
}