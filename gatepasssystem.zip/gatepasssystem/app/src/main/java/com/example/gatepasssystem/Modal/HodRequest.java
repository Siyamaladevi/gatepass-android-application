package com.example.gatepasssystem.Modal;

public class HodRequest {
    String name,dept,id,mob,date,com;
    public HodRequest(){

    }public HodRequest(String name, String dept, String id, String mob, String date, String comment){
        this.name=name;
        this.dept=dept;
        this.id=id;
        this.mob=mob;
        this.date=date;
        this.com=comment;
    }

    public String getDate() {
        return date;
    }

    public String getDept() {
        return dept;
    }

    public String getName() {
        return name;
    }

    public String getCom() {
        return com;
    }

    public String getId() {
        return id;
    }

    public String getMob() {
        return mob;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCom(String com) {
        this.com = com;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setMob(String mob) {
        this.mob = mob;
    }
}