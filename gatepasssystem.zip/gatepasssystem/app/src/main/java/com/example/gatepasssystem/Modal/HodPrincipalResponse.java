
package com.example.gatepasssystem.Modal;

public class HodPrincipalResponse {
    String name, ID, dept, branch, mobile, date, comment, pStatus, pCom;
    public HodPrincipalResponse(){


    }
    public HodPrincipalResponse(String name, String id, String date){
        this.name=name;
        this.ID=id;
        this.date=date;
    }

    public String getBranch() {
        return branch;
    }

    public String getComment() {
        return comment;
    }

    public String getDate() {
        return date;
    }

    public String getDept() {
        return dept;
    }

    public String getMobile() {
        return mobile;
    }


    public String getName() {
        return name;
    }

    public String getpCom() {
        return pCom;
    }

    public String getID() {
        return ID;
    }

    public String getpStatus() {
        return pStatus;
    }

    public void setpCom(String pCom) {
        this.pCom = pCom;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setpStatus(String pStatus) {
        this.pStatus = pStatus;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setName(String name) {
        this.name = name;
    }

}

