package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class StaffDashboard extends AppCompatActivity {
    CardView stuDetails,staffReq;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staffdashboard);
        stuDetails=findViewById(R.id.studet);
        staffReq=findViewById(R.id.stafreq);
        staffReq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent req=new Intent(StaffDashboard.this,StaffReq.class);
                startActivity(req);
            }
        });
        stuDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent req=new Intent(StaffDashboard.this, StuReqlist.class);
                startActivity(req);

            }
        });

    }
}