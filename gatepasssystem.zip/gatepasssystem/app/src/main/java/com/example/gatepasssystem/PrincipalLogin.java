package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PrincipalLogin extends AppCompatActivity {
    EditText username,password;
    Button submit;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principallogin);
        username=findViewById(R.id.user);
        password=findViewById(R.id.pass);
        submit=findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Username=username.getText().toString();
                String Password=password.getText().toString();

                if (Username.isEmpty()){
                    Toast.makeText(PrincipalLogin.this,"Enter Username",Toast.LENGTH_SHORT).show();
                } else if (Password.isEmpty()) {
                    Toast.makeText(PrincipalLogin.this,"Enter Password",Toast.LENGTH_SHORT).show();

                }
                else if (Username.equals("admin")&& Password.equals("admin")){
                    Toast.makeText(PrincipalLogin.this,"Login successfully!",Toast.LENGTH_SHORT).show();

                    Intent stud= new Intent(PrincipalLogin.this, PrincipalDashboard.class);
                    startActivity(stud);
                }
                else {
                    Toast.makeText(PrincipalLogin.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }


            }
        });

    }
}