package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.gatepasssystem.Adapter.StaffResAdapter;
import com.example.gatepasssystem.Adapter.StudentReqAdapter;
import com.example.gatepasssystem.Modal.StaffResponse;
import com.example.gatepasssystem.Modal.StudentRequest;

import java.util.ArrayList;

public class StafftoHodlist extends AppCompatActivity {

    ListView listView;

    MainDB db;
    StaffResponse staffResponse;
    StaffResAdapter ad;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staffto_hodlist);
        listView=findViewById(R.id.sthlist);

        db = new MainDB(this);
        ShowList();


    }
    private void ShowList(){
        final ArrayList<StaffResponse> data = new ArrayList<>(db.getvalues());
        ad = new StaffResAdapter(data,db,this);

        listView.setAdapter(ad);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                staffResponse = data.get(i);
            }
        });
    }
}