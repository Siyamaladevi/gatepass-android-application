package com.example.gatepasssystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.gatepasssystem.Modal.HodPrincipalResponse;
import com.example.gatepasssystem.Modal.HodRequest;
import com.example.gatepasssystem.Modal.HodResponse;
import com.example.gatepasssystem.Modal.StaffHodRequest;
import com.example.gatepasssystem.Modal.StaffPrincipalRes;
import com.example.gatepasssystem.Modal.StaffRequest;
import com.example.gatepasssystem.Modal.StaffResponse;
import com.example.gatepasssystem.Modal.StudentRequest;

import java.util.ArrayList;
import java.util.List;

public class MainDB extends SQLiteOpenHelper {
    private String Name;

    public MainDB(Context cn){
        super(cn,"studSign",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table StudentSign(Name TEXT,RegNo TEXT Primary key,Dept TEXT,Branch TEXT,Mobile TEXT,Parentmob TEXt,Address TEXt)");
        sqLiteDatabase.execSQL("Create table StaffSign( Name TEXT,Dept TEXT,ID TEXT Primary key,Mob TEXT,Password TEXT)");
        sqLiteDatabase.execSQL("create table HodSign(Name TEXT,Dept TEXT,ID TEXT Primary key,Mob TEXT,Password TEXT)");
        sqLiteDatabase.execSQL("create table stuRequest(Name Text,RegNo TEXT Primary Key,Dept Text,Branch TEXT,Mobile TEXT,ParentMob TEXT,Date TEXT,Comment TEXT)");
        sqLiteDatabase.execSQL("create table staffRes(Name Text,RegNo Text Primary Key,Dept Text,Branch TEXT,Mobile TEXT,ParentMob TEXT,Date TEXT,Comment TEXT,staffStatus TEXT,StaffCom TEXT)");
        sqLiteDatabase.execSQL("create table hodRes(Name Text,RegNo Text Primary Key,Dept Text,Branch TEXT,Date TEXT)");
        sqLiteDatabase.execSQL("create table StaffReq(Name TEXT,Dept TEXT,ID TEXT Primary key,Mob TEXT,Date TEXT,Comment TEXT)");
        sqLiteDatabase.execSQL("create table StaffHodRes(Name TEXT,ID TEXT Primary key,Date TEXT,hodStatus TEXT)");
        sqLiteDatabase.execSQL("create table StaffPrinRes(Name TEXT,ID TEXT Primary key,Date TEXT)");
        sqLiteDatabase.execSQL("create table HodReq(Name TEXT,Dept TEXT,ID TEXT Primary key,Mob TEXT,Date TEXT,Comment TEXT)");
        sqLiteDatabase.execSQL("create table hodPrinRes(Name TEXT,ID TEXT Primary key,Date TEXT,pStatus TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("Drop table if exists StudentSign");
        sqLiteDatabase.execSQL("Drop table if exists StaffSign");
        sqLiteDatabase.execSQL("Drop table if exists HodSign");
        sqLiteDatabase.execSQL("Drop table if exists stuRequest");
        sqLiteDatabase.execSQL("Drop table if exists staffRes");
        sqLiteDatabase.execSQL("Drop table if exists hodRes");
        sqLiteDatabase.execSQL("Drop table if exists StaffReq");
        sqLiteDatabase.execSQL("Drop table if exists StaffHodRes");
        sqLiteDatabase.execSQL("Drop table if exists StaffPrinRes");
        sqLiteDatabase.execSQL("Drop table if exists HodReq");
        sqLiteDatabase.execSQL("Drop table if exists HodPrinRes");

    }
    public Boolean insertStudent(String name,String regno,String dept,String branch,String mobile,String parentmon,String address){
        SQLiteDatabase  stuSql=getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("Name",name);
        cv.put("RegNo",regno);
        cv.put("Dept",dept);
        cv.put("Branch",branch);
        cv.put("Mobile",mobile);
        cv.put("Parentmob",parentmon);
        cv.put("Address",address);

        long result=stuSql.insert("StudentSign",null,cv);
        if (result==-1){
            return false;
        }else {
            return true;
        }
    }

    public Boolean insertStaff(String name, String dept,String id, String mob, String password) {
        SQLiteDatabase staffSql=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("Name",name);
        contentValues.put("Dept",dept);
        contentValues.put("ID",id);
        contentValues.put("Mob",mob);
        contentValues.put("Password",password);
        long res=staffSql.insert("StaffSign",null,contentValues);
        if (res==-1){
            return false;
        }else {
            return true;
        }

    }
    public Boolean insertHod(String name, String dept,String id, String mob, String password) {
        SQLiteDatabase staffSql=getWritableDatabase();
        ContentValues contentValues1=new ContentValues();
        contentValues1.put("Name",name);
        contentValues1.put("Dept",dept);
        contentValues1.put("ID",id);
        contentValues1.put("Mob",mob);
        contentValues1.put("Password",password);
        long res=staffSql.insert("HodSign",null,contentValues1);
        if (res==-1){
            return false;
        }else {
            return true;
        }

    }
    public Boolean insertStuReq(StudentRequest modal){
        SQLiteDatabase stuReqSql=getWritableDatabase();
        ContentValues contentValues2=new ContentValues();
        contentValues2.put("Name",modal.getName());
        contentValues2.put("RegNo",modal.getReg_no());
        contentValues2.put("Dept",modal.getDept());
        contentValues2.put("Branch",modal.getBranch());
        contentValues2.put("Mobile",modal.getMobile());
        contentValues2.put("ParentMob",modal.getP_no());
        contentValues2.put("Date",modal.getDate());
        contentValues2.put("Comment",modal.getComment());
        long res=stuReqSql.insert("StuRequest",null,contentValues2);
        if (res==-1){
            return false;
        }else {
            return true;
        }

    }
    public Boolean insertStaffRes(StaffResponse modal){
        SQLiteDatabase staffResSql=getWritableDatabase();
        ContentValues contentValues3=new ContentValues();
        contentValues3.put("Name",modal.getName());
        contentValues3.put("RegNo",modal.getRegNo());
        contentValues3.put("Dept",modal.getDept());
        contentValues3.put("Branch",modal.getBranch());
        contentValues3.put("Mobile",modal.getMobile());
        contentValues3.put("ParentMob",modal.getParentMob());
        contentValues3.put("Date",modal.getDate());
        contentValues3.put("Comment",modal.getComment());
        contentValues3.put("staffStatus",modal.getStaffStatus());
        contentValues3.put("staffCom",modal.getStaffCom());
        long res=staffResSql.insert("StaffRes",null,contentValues3);
        if (res==-1){
            return false;
        }else {
            return true;
        }

    }
    public Boolean insertHodRes(HodResponse modal)
    {
        SQLiteDatabase HodResSql=getWritableDatabase();
        ContentValues contentValues4=new ContentValues();
        contentValues4.put("Name",modal.getName());
        contentValues4.put("RegNo",modal.getRegNo());
        contentValues4.put("Dept",modal.getDept());
        contentValues4.put("Branch",modal.getBranch());
        contentValues4.put("Date",modal.getDate());
        long res=HodResSql.insert("hodRes",null,contentValues4);
        if (res==-1){
            return false;
        }else {
            return true;
        }

    }
    public Boolean insertStaffReq(StaffRequest modal) {
        SQLiteDatabase staffReqSql=getWritableDatabase();
        ContentValues contentValues5=new ContentValues();
        contentValues5.put("Name",modal.getName());
        contentValues5.put("Dept",modal.getDept());
        contentValues5.put("ID",modal.getId());
        contentValues5.put("Mob",modal.getMob());
        contentValues5.put("Date",modal.getDate());
        contentValues5.put("Comment",modal.getCom());
        long res=staffReqSql.insert("staffReq",null,contentValues5);
        if (res==-1){
            return false;
        }else {
            return true;
        }

    }
    public Boolean insertStaffHodRes(StaffHodRequest modal) {
        SQLiteDatabase staffHodResSql=getWritableDatabase();
        ContentValues contentValues6=new ContentValues();
        contentValues6.put("Name",modal.getName());
        contentValues6.put("ID",modal.getID());
        contentValues6.put("Date",modal.getDate());
        contentValues6.put("hodStatus",modal.gethodStatus());
        long res=staffHodResSql.insert("StaffHodRes",null,contentValues6);
        if (res==-1){
            return false;
        }else {
            return true;
        }

    }
    public Boolean insertStaffPrinRes(StaffPrincipalRes modal) {
        SQLiteDatabase staffPrinResSql=getWritableDatabase();
        ContentValues contentValues7=new ContentValues();
        contentValues7.put("Name",modal.getName());
        contentValues7.put("ID",modal.getID());
        contentValues7.put("Date",modal.getDate());
        long res=staffPrinResSql.insert("StaffPrinRes",null,contentValues7);
        if (res==-1){
            return false;
        }else {
            return true;
        }

    }
    public Boolean insertHodReq(HodRequest modal) {
        SQLiteDatabase hodReqSql=getWritableDatabase();
        ContentValues contentValues8=new ContentValues();
        contentValues8.put("Name",modal.getName());
        contentValues8.put("Dept",modal.getDept());
        contentValues8.put("ID",modal.getId());
        contentValues8.put("Mob",modal.getMob());
        contentValues8.put("Date",modal.getDate());
        contentValues8.put("Comment",modal.getCom());
        long res=hodReqSql.insert("HodReq",null,contentValues8);
        if (res==-1){
            return false;
        }else {
            return true;
        }

    }
    public Boolean insertHodPrinRes(HodPrincipalResponse modal) {
        SQLiteDatabase hodPrinresSql=getWritableDatabase();
        ContentValues contentValues9=new ContentValues();
        contentValues9.put("Name",modal.getName());
        contentValues9.put("ID",modal.getID());

        contentValues9.put("Date",modal.getDate());



        long res=hodPrinresSql.insert("hodPrinRes",null,contentValues9);
        if (res==-1){
            return false;
        }else {
            return true;
        }

    }public List<StudentRequest> getvalue() {
        List<StudentRequest> list = new ArrayList<StudentRequest>();

        String SelectQuery = "SELECT * FROM stuRequest";

        SQLiteDatabase Db = this.getWritableDatabase();
        Cursor cursor = Db.rawQuery(SelectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                StudentRequest modal = new StudentRequest();
                modal.setName(cursor.getString(0));
                modal.setReg_no(cursor.getString(1));
                modal.setDept(cursor.getString(2));
                modal.setBranch(cursor.getString(3));
                modal.setDate(cursor.getString(6));
                modal.setP_no(cursor.getString(5));
                modal.setComment(cursor.getString(7));

                list.add(modal);
            } while (cursor.moveToNext());
        }

        return list;
    }
    public List<StaffResponse> getvalues() {
        List<StaffResponse> list = new ArrayList<StaffResponse>();

        String SelectQuery = "SELECT * FROM staffRes";

        SQLiteDatabase Db = this.getWritableDatabase();
        Cursor cursor = Db.rawQuery(SelectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                StaffResponse modal = new StaffResponse();
                modal.setName(cursor.getString(0));
                modal.setRegNo(cursor.getString(1));
                modal.setDept(cursor.getString(2));
                modal.setBranch(cursor.getString(3));
                modal.setDate(cursor.getString(6));
                modal.setParentMob(cursor.getString(5));
                modal.setComment(cursor.getString(7));
                modal.setStaffStatus(cursor.getString(8));
                modal.setStaffCom(cursor.getString(9));

                list.add(modal);
            } while (cursor.moveToNext());
        }

        return list;
    }
    public List<HodResponse>getvaluess() {
        List<HodResponse> list = new ArrayList<HodResponse>();

        String SelectQuery = "SELECT * FROM hodRes";

        SQLiteDatabase Db = this.getWritableDatabase();
        Cursor cursor = Db.rawQuery(SelectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                HodResponse modal = new HodResponse();
                modal.setName(cursor.getString(0));
                modal.setRegNo(cursor.getString(1));
                modal.setDept(cursor.getString(2));
                modal.setBranch(cursor.getString(3));
                modal.setDate(cursor.getString(4));

                list.add(modal);
            } while (cursor.moveToNext());
        }

        return list;
    }
    public List<StaffRequest>getval() {
        List<StaffRequest> list = new ArrayList<>();

        String SelectQuery = "SELECT * FROM StaffReq";

        SQLiteDatabase Db = this.getWritableDatabase();
        Cursor cursor = Db.rawQuery(SelectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                StaffRequest modal = new StaffRequest();
                modal.setName(cursor.getString(0));
                modal.setId(cursor.getString(2));
                modal.setDept(cursor.getString(1));
                modal.setCom(cursor.getString(5));
                modal.setDate(cursor.getString(4));
                modal.setMob(cursor.getString(3));

                list.add(modal);
            } while (cursor.moveToNext());
        }

        return list;
    }
    public List<StaffHodRequest>getv() {
        List<StaffHodRequest> list = new ArrayList<>();

        String SelectQuery = "SELECT * FROM StaffHodRes";

        SQLiteDatabase Db = this.getWritableDatabase();
        Cursor cursor = Db.rawQuery(SelectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                StaffHodRequest modal = new StaffHodRequest();
                modal.setName(cursor.getString(0));
                modal.setID(cursor.getString(1));
                modal.setDate(cursor.getString(2));
                modal.sethodStatus(cursor.getString(3));

                list.add(modal);
            } while (cursor.moveToNext());
        }

        return list;
    }
    public List<StaffPrincipalRes>getval1() {
        List<StaffPrincipalRes> list = new ArrayList<>();

        String SelectQuery = "SELECT * FROM StaffPrinRes";

        SQLiteDatabase Db = this.getWritableDatabase();
        Cursor cursor = Db.rawQuery(SelectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                StaffPrincipalRes modal = new StaffPrincipalRes();
                modal.setName(cursor.getString(0));
                modal.setID(cursor.getString(1));
                modal.setDate(cursor.getString(2));


                list.add(modal);
            } while (cursor.moveToNext());
        }

        return list;
    }
    public List<HodRequest>getval2() {
        List<HodRequest> list = new ArrayList<>();

        String SelectQuery = "SELECT * FROM HodReq";

        SQLiteDatabase Db = this.getWritableDatabase();
        Cursor cursor = Db.rawQuery(SelectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                HodRequest modal = new HodRequest();
                modal.setName(cursor.getString(0));
                modal.setId(cursor.getString(2));
                modal.setDept(cursor.getString(1));
                modal.setCom(cursor.getString(5));
                modal.setDate(cursor.getString(4));
                modal.setMob(cursor.getString(3));


                list.add(modal);
            } while (cursor.moveToNext());
        }

        return list;
    }
    public List<HodPrincipalResponse>getval3() {
        List<HodPrincipalResponse> list = new ArrayList<>();

        String SelectQuery = "SELECT * FROM hodPrinRes";

        SQLiteDatabase Db = this.getWritableDatabase();
        Cursor cursor = Db.rawQuery(SelectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                HodPrincipalResponse modal = new HodPrincipalResponse();
                modal.setName(cursor.getString(0));
                modal.setID(cursor.getString(1));
                modal.setDate(cursor.getString(2));

                list.add(modal);
            } while (cursor.moveToNext());
        }

        return list;
    }
    public Boolean CheckStudentNameandPassword(String username, String password){
        SQLiteDatabase DB=this.getWritableDatabase();
        Cursor cursor=DB.rawQuery("Select * from StudentSign where RegNo=? and Mobile=?",new String[]{username,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean checkstudentname(String username){
        SQLiteDatabase DB=this.getWritableDatabase();
        Cursor cursor=DB.rawQuery("select * from StudentSign where Regno=?",new String[]{username});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean CheckStaffNameandPassword(String username, String password){
        SQLiteDatabase DB=this.getWritableDatabase();
        Cursor cursor=DB.rawQuery("Select * from StaffSign where ID=? and Password=?",new String[]{username,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean checkstaffname(String username){
        SQLiteDatabase DB=this.getWritableDatabase();
        Cursor cursor=DB.rawQuery("select * from StaffSign where ID=?",new String[]{username});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean CheckHodNameandPassword(String username, String password){
        SQLiteDatabase DB=this.getWritableDatabase();
        Cursor cursor=DB.rawQuery("Select * from HodSign where ID=? and Password=?",new String[]{username,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean checkhodname(String username){
        SQLiteDatabase DB=this.getWritableDatabase();
        Cursor cursor=DB.rawQuery("select * from HodSign where ID=?",new String[]{username});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }



}
