package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class StaffLogin extends AppCompatActivity {
    EditText username, password;
    RadioGroup staffHod;
    RadioButton select;
    TextView signup;
    MainDB DB;

    Button submit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stafflogin);
        username = findViewById(R.id.user);
        password = findViewById(R.id.pass);
        submit = findViewById(R.id.submit);
        signup=findViewById(R.id.signup);
        staffHod=findViewById(R.id.button);
        DB=new MainDB(this);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectstaff=staffHod.getCheckedRadioButtonId();
                select=findViewById(selectstaff);
                String Username = username.getText().toString();
                String Password = password.getText().toString();
                String Select= select.getText().toString();

                if (Username.isEmpty()) {
                    Toast.makeText(StaffLogin.this, "Enter Username", Toast.LENGTH_SHORT).show();
                } else if (Password.isEmpty()) {
                    Toast.makeText(StaffLogin.this, "Enter Password", Toast.LENGTH_SHORT).show();

                } else if (Select.equals("Staff")) {
                    Boolean checkdata=DB.CheckStaffNameandPassword(Username,Password);
                      if (checkdata==true) {
                          Toast.makeText(StaffLogin.this, "Login successfully!", Toast.LENGTH_SHORT).show();
                          Intent s = new Intent(StaffLogin.this, StaffDashboard.class);
                          startActivity(s);
                      }else {
                          Toast.makeText(StaffLogin.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                      }

                } else if(Select.equals("HOD"))
                {
                    Boolean checkdata=DB.CheckHodNameandPassword(Username,Password);
                    if (checkdata==true) {
                        Toast.makeText(StaffLogin.this, "Login successfully!", Toast.LENGTH_SHORT).show();

                        Intent stud = new Intent(StaffLogin.this, HodDashboard.class);
                        startActivity(stud);
                    }else
                        Toast.makeText(StaffLogin.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                }


            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signup = new Intent(StaffLogin.this, StaffSignup.class);
                startActivity(signup);
            }
        });
    }
}
