package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.gatepasssystem.Adapter.StudentReqAdapter;
import com.example.gatepasssystem.Modal.StudentRequest;

import java.util.ArrayList;

public class StuReqlist extends AppCompatActivity {

    ListView listView;

    MainDB db;
    StudentRequest stuReq;
    StudentReqAdapter ad;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stu_reqlist);
        listView=findViewById(R.id.list);

        db = new MainDB(this);
        ShowList();


    }
    private void ShowList(){
        final ArrayList<StudentRequest> data = new ArrayList<>(db.getvalue());
        ad = new StudentReqAdapter(data,db,this);

        listView.setAdapter(ad);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                stuReq = data.get(i);
            }
        });
    }
}