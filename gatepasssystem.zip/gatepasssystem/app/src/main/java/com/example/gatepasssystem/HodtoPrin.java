package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.gatepasssystem.Modal.HodPrincipalResponse;
import com.example.gatepasssystem.Modal.HodRequest;
import com.example.gatepasssystem.Modal.StaffPrincipalRes;

public class HodtoPrin extends AppCompatActivity {
    EditText com;
    String Apr[] = {"Request Status", "Approved", "Not Approved"};
    String apv, name, id, date, number;
    Button sub;
    MainDB db;
    Spinner approval;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hodto_prin);
        com = findViewById(R.id.com);
        approval = findViewById(R.id.apr);
        sub = findViewById(R.id.sub);
        db = new MainDB(this);
        getspin();
        getval3();
        SharedPreferences hodsign = getSharedPreferences("hodkey", MODE_PRIVATE);
        number = hodsign.getString("mob", "");

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Comment = com.getText().toString();
                if (Comment.isEmpty()) {
                    Toast.makeText(HodtoPrin.this, "Enter Comment", Toast.LENGTH_SHORT).show();
                } else {
                    if (apv.equals("Approved")) {
                        Boolean CheckData = db.insertHodPrinRes(new HodPrincipalResponse(name, id, date));
                        if (CheckData == true) {
                            Toast.makeText(HodtoPrin.this, "Submitted Successfully!", Toast.LENGTH_SHORT).show();
                            alert3();
                        } else {
                            Toast.makeText(HodtoPrin.this, "Failed", Toast.LENGTH_SHORT).show();
                        }
                    } else if (apv.equals("Not Approved")) {
                        Toast.makeText(HodtoPrin.this, "Staff denied the Gate Pass", Toast.LENGTH_SHORT).show();
                        alert4();
                    }

                }

            }
        });
    }

    public void getspin() {
        ArrayAdapter appArr = new ArrayAdapter<>(HodtoPrin.this, android.R.layout.simple_spinner_item, Apr);
        appArr.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        approval.setAdapter(appArr);

        approval.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                apv = approval.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void getval3() {
        Intent i = getIntent();
        name = i.getStringExtra("name");
        id = i.getStringExtra("id");
        date = i.getStringExtra("date");
    }

    private void alert3() {
        String content = "Your requesting pass has been approved";
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(number, null, content, null, null);
            Toast.makeText(getApplicationContext(), "Sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), e.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }
    private void alert4(){
        String content="Your requesting pass has been denied";
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(number, null, content, null, null);
            Toast.makeText(getApplicationContext(),"Sent",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage().toString(),Toast.LENGTH_SHORT).show();
        }
    }
}


