package com.example.gatepasssystem.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.gatepasssystem.Finallist;
import com.example.gatepasssystem.MainDB;
import com.example.gatepasssystem.Modal.HodResponse;
import com.example.gatepasssystem.Modal.StaffPrincipalRes;
import com.example.gatepasssystem.R;
import com.example.gatepasssystem.StoPFinal;

import java.util.ArrayList;

public class StoPAdapter extends ArrayAdapter<StaffPrincipalRes> {
    Context c;

    public StoPAdapter(ArrayList<StaffPrincipalRes> listModal , MainDB Db, Context context) {
        super(context, R.layout.sfinallist,listModal);
    }

    public class Holder{
        TextView Name,ID,Date;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        StaffPrincipalRes data = getItem(position);

        final Holder viewHolder;

        if (convertView==null){

            viewHolder = new Holder();

            LayoutInflater inflater =LayoutInflater.from(getContext());
            convertView =inflater.inflate(R.layout.sfinallist,parent,false);
            viewHolder.Name=convertView.findViewById(R.id.n1);
            viewHolder.ID=convertView.findViewById(R.id.id1);
            viewHolder.Date=convertView.findViewById(R.id.d1);


            convertView.setTag(viewHolder);

            String name =viewHolder.Name.getText().toString();
            String id =viewHolder.ID.getText().toString();
            String date =viewHolder.Date.getText().toString();

            Intent intent=new Intent(getContext(), StoPFinal.class);
            intent.putExtra("name",name);
            intent.putExtra("id",id);
            intent.putExtra("date",date);
        }
        else {
            viewHolder = (Holder) convertView.getTag();
        }

        viewHolder.Name.setText(data.getName());
        viewHolder.ID.setText(data.getID());
        viewHolder.Date.setText(data.getDate());


        return convertView;
    }

}
