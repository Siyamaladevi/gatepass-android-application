package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class StudentLogin extends AppCompatActivity {
    EditText username,password;
    TextView signup;
    MainDB DB;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentlogin);
        username=findViewById(R.id.user);
        password=findViewById(R.id.pass);
        submit=findViewById(R.id.submit);
        signup=findViewById(R.id.signup);
        DB=new MainDB(this);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Username=username.getText().toString();
                String Password=password.getText().toString();

                if (Username.isEmpty()){
                    Toast.makeText(StudentLogin.this,"Enter Username",Toast.LENGTH_SHORT).show();
                } else if (Password.isEmpty()) {
                    Toast.makeText(StudentLogin.this,"Enter Password",Toast.LENGTH_SHORT).show();

                }
                else {
                    Boolean checkdata=DB.CheckStudentNameandPassword(Username,Password);
                    if (checkdata==true){
                        Toast.makeText(StudentLogin.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                        Intent stud= new Intent(StudentLogin.this, StudDashboard.class);
                        startActivity(stud);

                    }
                    else {
                        Toast.makeText(StudentLogin.this, "Invalid Crendentials", Toast.LENGTH_SHORT).show();
                    }


                }


            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signup=new Intent(StudentLogin.this, StudentSignup.class);
                startActivity(signup);
            }
        });




    }
}