package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.gatepasssystem.Modal.StaffRequest;
import com.example.gatepasssystem.Modal.StudentRequest;

import java.util.Calendar;

public class StaffReq extends AppCompatActivity {
    String mob,name,id,dept;
    EditText date,comment,Cal;
    ImageView calendar;
    MainDB data;
    int da,mo,ye;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_req);
        //place=findViewById(R.id.place);
        date=findViewById(R.id.date);
        calendar=findViewById(R.id.cal);
        Cal=findViewById(R.id.date);
        comment=findViewById(R.id.com);
        submit=findViewById(R.id.sub);
        data=new MainDB(this);

        SharedPreferences staffsign=getSharedPreferences("staffKey",MODE_PRIVATE);
        name=staffsign.getString("name","");
        id=staffsign.getString("id","");
        dept=staffsign.getString("dept","");
        mob=staffsign.getString("mob","");





        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //String Place=place.getText().toString();
                String Date = date.getText().toString();
                String Comm = comment.getText().toString();

                //if (Place.isEmpty()){
                //Toast.makeText(StaffReq.this, "Enter Place", Toast.LENGTH_SHORT).show();
                if (Date.isEmpty()) {
                    Toast.makeText(StaffReq.this, "Enter Date", Toast.LENGTH_SHORT).show();
                } else if (Comm.isEmpty()) {
                    Toast.makeText(StaffReq.this, "Enter Comment", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean CheckData = data.insertStaffReq(new StaffRequest(name, id, dept,mob,Date,Comm));
                    if (CheckData == true) {

                        Toast.makeText(StaffReq.this, "Submitted Successfully! ", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(StaffReq.this, "failed", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal=Calendar.getInstance();
                da=cal.get(Calendar.DAY_OF_MONTH);
                mo=cal.get(Calendar.MONTH);
                ye=cal.get(Calendar.YEAR);
                DatePickerDialog caldr= new DatePickerDialog(StaffReq.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        Cal.setText(i2+"/"+(i1+1)+"/"+i);
                    }
                },da,mo,ye);
                caldr.show();


            }
        });
    }
}