package com.example.gatepasssystem.Modal;
public class HodResponse {
    String name, regNo, dept, branch, mobile, parentMob, date, comment, staffStatus, staffCom,hodSts,hodCom;
    public HodResponse(){

    }

    public HodResponse(String name, String regNo, String dept, String branch, String date) {
        this.name=name;
        this.regNo=regNo;
        this.dept=dept;
        this.branch=branch;
        this.date=date;
    }

    public String getName() {
        return name;
    }

    public String getRegNo() {
        return regNo;
    }

    public String getDept() {
        return dept;
    }

    public String getBranch() {
        return branch;
    }

    public String getMobile() {
        return mobile;
    }

    public String getParentMob() {
        return parentMob;
    }

    public String getDate() {
        return date;
    }

    public String getComment() {
        return comment;
    }



    public String getStaffStatus() {
        return staffStatus;
    }

    public String getStaffCom() {
        return staffCom;
    }

    public String getHodSts() {
        return hodSts;
    }

    public String getHodCom() {
        return hodCom;
    }

    public void setHodSts(String hodSts) {
        this.hodSts = hodSts;
    }

    public void setHodCom(String hodCom) {
        this.hodCom = hodCom;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setParentMob(String parentMob) {
        this.parentMob = parentMob;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setStaffStatus(String staffStatus) {
        this.staffStatus = staffStatus;
    }

    public void setStaffCom(String staffCom) {
        this.staffCom = staffCom;
    }
}
