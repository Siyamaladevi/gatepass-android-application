package com.example.gatepasssystem.Adapter;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.gatepasssystem.MainDB;
import com.example.gatepasssystem.Modal.StaffResponse;
import com.example.gatepasssystem.Modal.StudentRequest;
import com.example.gatepasssystem.R;
import com.example.gatepasssystem.StutoSta;

import java.util.ArrayList;
import java.util.jar.Attributes;

public class StudentReqAdapter extends ArrayAdapter<StudentRequest > {
    Context c;

    public StudentReqAdapter(ArrayList<StudentRequest> listModal , MainDB Db, Context context) {
        super(context, R.layout.listview,listModal);
    }

    public class Holder{
        TextView Name,RegNo,Dept,Branch,Date,Comment,ParNo;
        Button btn;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        StudentRequest data = getItem(position);

        final Holder viewHolder;

        if (convertView==null){

            viewHolder = new Holder();

            LayoutInflater inflater =LayoutInflater.from(getContext());
            convertView =inflater.inflate(R.layout.listview,parent,false);
            viewHolder.Name=convertView.findViewById(R.id.n1);
            viewHolder.RegNo=convertView.findViewById(R.id.r1);
            viewHolder.Dept=convertView.findViewById(R.id.d1);
            viewHolder.Branch=convertView.findViewById(R.id.b1);
            viewHolder.Date=convertView.findViewById(R.id.date1);
            viewHolder.ParNo=convertView.findViewById(R.id.pn1);
            viewHolder.Comment=convertView.findViewById(R.id.c1);
            viewHolder.btn=convertView.findViewById(R.id.btn);
            viewHolder.btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String name =viewHolder.Name.getText().toString();
                    String regNo=viewHolder.RegNo.getText().toString();
                    String dept=viewHolder.Dept.getText().toString();
                    String branch=viewHolder.Branch.getText().toString();
                    String date=viewHolder.Date.getText().toString();
                    String parNo=viewHolder.ParNo.getText().toString();
                    String comment=viewHolder.Comment.getText().toString();


                    Intent intent=new Intent(getContext(),StutoSta.class);
                    intent.putExtra("name",name);
                    intent.putExtra("regNo",regNo);
                    intent.putExtra("dept",dept);
                    intent.putExtra("branch",branch);
                    intent.putExtra("date",date);
                    intent.putExtra("parno",parNo);
                    intent.putExtra("comment",comment);
                    getContext().startActivity(intent);


                }
            });


            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (Holder) convertView.getTag();
        }

        viewHolder.Name.setText(data.getName());
        viewHolder.RegNo.setText(data.getReg_no());
        viewHolder.Dept.setText(data.getDept());
        viewHolder.Branch.setText(data.getBranch());
        viewHolder.Date.setText(data.getDate());
        viewHolder.ParNo.setText(data.getP_no());
        viewHolder.Comment.setText(data.getComment());



        return convertView;
    }
}
