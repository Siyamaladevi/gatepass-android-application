package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.gatepasssystem.Adapter.HodReqAdapter;
import com.example.gatepasssystem.Adapter.StaffReqAdapter;
import com.example.gatepasssystem.Adapter.StudentReqAdapter;
import com.example.gatepasssystem.Modal.HodRequest;
import com.example.gatepasssystem.Modal.StaffRequest;
import com.example.gatepasssystem.Modal.StudentRequest;

import java.util.ArrayList;

public class HodReqList extends AppCompatActivity {

    ListView listView;

    MainDB db;
    HodRequest hodRequest;
    HodReqAdapter ad;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hod_req_list);
        listView=findViewById(R.id.list);

        db = new MainDB(this);
        ShowList();


    }
    private void ShowList(){
        final ArrayList<HodRequest> data = new ArrayList<>(db.getval2());
        ad = new HodReqAdapter(data,db,this);

        listView.setAdapter(ad);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                hodRequest = data.get(i);
            }
        });
    }
}