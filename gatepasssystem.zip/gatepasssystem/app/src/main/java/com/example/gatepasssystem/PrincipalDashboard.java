package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class PrincipalDashboard extends AppCompatActivity {
    CardView HodReqDet,StaffReqDet,ViewStuList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principaldashboard);
        HodReqDet=findViewById(R.id.hoddet);
        StaffReqDet=findViewById(R.id.staffdet);
        ViewStuList=findViewById(R.id.apvdet);

        ViewStuList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(PrincipalDashboard.this, Finallist.class);
                startActivity(intent);
            }
        });StaffReqDet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(PrincipalDashboard.this,StaffFinalList.class);
                startActivity(i);
            }
        });
        HodReqDet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(PrincipalDashboard.this,HodReqList.class);
                startActivity(i);
            }
        });
    }

}