package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.gatepasssystem.Adapter.StaffReqAdapter;
import com.example.gatepasssystem.Adapter.StudentReqAdapter;
import com.example.gatepasssystem.Modal.StaffRequest;
import com.example.gatepasssystem.Modal.StudentRequest;

import java.util.ArrayList;

public class StaffReqList extends AppCompatActivity {

    ListView listView;

    MainDB db;
    StaffRequest staffReq;
    StaffReqAdapter ad;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_req_list);
        listView=findViewById(R.id.list);

        db = new MainDB(this);
        ShowList();


    }
    private void ShowList(){
        final ArrayList<StaffRequest> data = new ArrayList<>(db.getval());
        ad = new StaffReqAdapter(data,db,this);

        listView.setAdapter(ad);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                staffReq = data.get(i);
            }
        });
    }
}