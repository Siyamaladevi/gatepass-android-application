package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class StudDashboard extends AppCompatActivity {
    CardView studReq,reqSts;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studdashboard);
        studReq=findViewById(R.id.stud);
        reqSts=findViewById(R.id.req);
        studReq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent req=new Intent(StudDashboard.this, StudentReq.class);
                startActivity(req);
            }
        });
        reqSts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(StudDashboard.this, Finallist.class);
                startActivity(intent);
            }
        });


    }
}