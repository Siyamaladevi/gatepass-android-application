package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PrincipalSignup extends AppCompatActivity {
    EditText name,mobile,password;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principalsignup);
        name=findViewById(R.id.yourname);
        mobile=findViewById(R.id.mobile);
        password=findViewById(R.id.password);
        submit=findViewById(R.id.btn);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Name=name.getText().toString();
                String Mobile=mobile.getText().toString();
                String Password=password.getText().toString();
                if (Name.isEmpty()){
                    Toast.makeText(PrincipalSignup.this, "Enter Name", Toast.LENGTH_SHORT).show();
                } else if (Mobile.isEmpty()) {
                    Toast.makeText(PrincipalSignup.this,"Enter Mobile Number",Toast.LENGTH_SHORT).show();
                } else if (Password.isEmpty()) {
                    Toast.makeText(PrincipalSignup.this,"Enter Password",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(PrincipalSignup.this,"Signup Successfully",Toast.LENGTH_SHORT).show();
                    Intent PSignup=new Intent(PrincipalSignup.this,PrincipalLogin.class);
                    startActivity(PSignup);
                }

            }
        });
    }
}