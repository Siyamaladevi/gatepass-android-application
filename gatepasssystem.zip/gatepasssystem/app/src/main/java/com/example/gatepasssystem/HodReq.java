package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.gatepasssystem.Modal.HodRequest;
import com.example.gatepasssystem.Modal.StaffRequest;

import java.util.Calendar;

public class HodReq extends AppCompatActivity {
    String name,id,mob,dept;
    EditText date,comment,Cal;
    ImageView calendar;
    MainDB data;
    int dat,month,year;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hod_req);
        //place=findViewById(R.id.place);
        date=findViewById(R.id.date);
        calendar=findViewById(R.id.cal);
        Cal=findViewById(R.id.date);
        comment=findViewById(R.id.com);
        submit=findViewById(R.id.sub);
        data=new MainDB(this);

        SharedPreferences hodsign=getSharedPreferences("hodkey",MODE_PRIVATE);
        name=hodsign.getString("name","");
        id=hodsign.getString("id","");
        dept=hodsign.getString("dept","");
        mob=hodsign.getString("mob","");


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Date=date.getText().toString();
                String Comm=comment.getText().toString();
                if (Date.isEmpty()) {
                    Toast.makeText(HodReq.this, "Enter Date", Toast.LENGTH_SHORT).show();
                } else if (Comm.isEmpty()) {
                    Toast.makeText(HodReq.this, "Enter Comment", Toast.LENGTH_SHORT).show();
                }else {
                    Boolean CheckData = data.insertHodReq(new HodRequest(name, id, dept,mob,Date,Comm));
                    if (CheckData == true) {

                        Toast.makeText(HodReq.this, "Submitted Successfully! ", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(HodReq.this, "failed", Toast.LENGTH_SHORT).show();
                    }

                    }
            }
        });
        calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal=Calendar.getInstance();
                dat=cal.get(Calendar.DAY_OF_MONTH);
                month=cal.get(Calendar.MONTH);
                year=cal.get(Calendar.YEAR);
                DatePickerDialog caldr= new DatePickerDialog(HodReq.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        Cal.setText(i2+"/"+(i1+1)+"/"+i);
                    }
                },dat,month,year);
                caldr.show();


            }
        });
    }
}