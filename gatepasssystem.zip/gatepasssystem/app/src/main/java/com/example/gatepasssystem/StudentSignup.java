package com.example.gatepasssystem;

import static com.example.gatepasssystem.R.id.sn;
import static com.example.gatepasssystem.R.id.submit;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class StudentSignup extends AppCompatActivity {
    EditText stuName,regNo,dept,parentMob,mob,pass;
    String bch[]={"Select Your Branch","I_Year","II_Year","III_Year","IV_Year"};
    Spinner br;
    MainDB data;
    String brStr;
    Button Submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentsignup);
        stuName=findViewById(R.id.sn);
        regNo=findViewById(R.id.rn);
        dept=findViewById(R.id.dep);
        br=findViewById(R.id.br);
        mob=findViewById(R.id.mob);
        parentMob=findViewById(R.id.pmn);
        pass=findViewById(R.id.pw);
        Submit=findViewById(submit);
        data=new MainDB(this);

        ArrayAdapter brArr=new ArrayAdapter<>(StudentSignup.this, android.R.layout.simple_spinner_item,bch);
        brArr.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        br.setAdapter(brArr);

        br.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                 brStr=br.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String StudentName=stuName.getText().toString();
                String RegNo=regNo.getText().toString();
                String Dept=dept.getText().toString();
                String ParentMob=parentMob.getText().toString();
                String Mobile=mob.getText().toString();
                String Address=pass.getText().toString();


                if (StudentName.isEmpty()){
                    Toast.makeText(StudentSignup.this,"Enter Student Name",Toast.LENGTH_SHORT).show();
                }
                else if (RegNo.isEmpty()) {
                    Toast.makeText(StudentSignup.this,"Enter Register Number",Toast.LENGTH_SHORT).show();

                }
                else if (Dept.isEmpty()) {
                    Toast.makeText(StudentSignup.this,"Enter Department",Toast.LENGTH_SHORT).show();
                }else if (Mobile.isEmpty()) {
                    Toast.makeText(StudentSignup.this,"Enter Mobile Number",Toast.LENGTH_SHORT).show();
                }
                else if (ParentMob.isEmpty()) {
                    Toast.makeText(StudentSignup.this, "Enter Parent Mobile Number", Toast.LENGTH_SHORT).show();
                }
                else if (Address.isEmpty()) {
                    Toast.makeText(StudentSignup.this,"Enter Address",Toast.LENGTH_SHORT).show();

                }
                else {
                    SharedPreferences studSign=getSharedPreferences("studKey",MODE_PRIVATE);
                    SharedPreferences.Editor editor=studSign.edit();
                    editor.putString("name",StudentName);
                    editor.putString("regNo",RegNo);
                    editor.putString("dept",Dept);
                    editor.putString("br",brStr);
                    editor.putString("pnm",ParentMob);
                    editor.putString("mob",Mobile);
                    editor.apply();
                    Boolean checkStudentname=data.checkstudentname(RegNo);
                    if (checkStudentname==false) {
                        Boolean bn = data.insertStudent(StudentName, RegNo, brStr, Dept, Mobile, ParentMob, Address);
                        if (bn == true) {

                            Toast.makeText(StudentSignup.this, "Signup Successfully", Toast.LENGTH_SHORT).show();
                            Intent StudSignup = new Intent(StudentSignup.this, StudentLogin.class);
                            startActivity(StudSignup);
                        } else {
                            Toast.makeText(StudentSignup.this, "failed", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(StudentSignup.this, "Username already exixts!", Toast.LENGTH_SHORT).show();
                    }


                }


            }
        });


    }
}