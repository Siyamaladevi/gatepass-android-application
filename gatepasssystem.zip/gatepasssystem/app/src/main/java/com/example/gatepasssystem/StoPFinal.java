package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.gatepasssystem.Adapter.StaffHodAdapter;
import com.example.gatepasssystem.Adapter.StoPAdapter;
import com.example.gatepasssystem.Modal.HodResponse;
import com.example.gatepasssystem.Modal.StaffHodRequest;
import com.example.gatepasssystem.Modal.StaffPrincipalRes;

import java.util.ArrayList;

public class StoPFinal extends AppCompatActivity {
    ListView listView;

    MainDB db;
    StaffPrincipalRes staffPrincipalRes;
    StoPAdapter ad;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sto_pfinal);
        listView=findViewById(R.id.list);

        db = new MainDB(this);
        ShowList();


    }
    private void ShowList(){
        final ArrayList<StaffPrincipalRes> data = new ArrayList<>(db.getval1());
        ad = new StoPAdapter(data,db,this);

        listView.setAdapter(ad);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                staffPrincipalRes = data.get(i);
            }
        });
    }
}