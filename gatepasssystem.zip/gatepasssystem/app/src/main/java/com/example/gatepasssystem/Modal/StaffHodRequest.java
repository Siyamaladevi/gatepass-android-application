package com.example.gatepasssystem.Modal;
public class StaffHodRequest {
    String name,dept,id,mob,date,com,hodStatus,hodCom;

    public StaffHodRequest(){

    }

    public StaffHodRequest(String name, String ID, String date, String hodStatus){
        this.name=name;
        this.id=ID;
        this.date=date;
        this.hodStatus=hodStatus;


    }

    public String getDate() {
        return date;
    }

    public String getDept() {
        return dept;
    }

    public String getName() {
        return name;
    }

    public String getCom() {
        return com;
    }

    public String getID() {
        return id;
    }

    public String getMob() {
        return mob;
    }

    public String getHodCom() {
        return hodCom;
    }

    public String gethodStatus() {
        return hodStatus;
    }

    public void setHodCom(String hodCom) {
        this.hodCom = hodCom;
    }

    public void sethodStatus(String hodStatus) {
        this.hodStatus = hodStatus;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCom(String com) {
        this.com = com;
    }

    public void setID(String id) {
        this.id = id;
    }

    public void setMob(String mob) {
        this.mob = mob;
    }
}
