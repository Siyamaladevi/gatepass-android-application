package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.gatepasssystem.Adapter.HodResAdapter;
import com.example.gatepasssystem.Modal.HodResponse;
import com.example.gatepasssystem.Modal.StaffResponse;

import java.util.ArrayList;

public class Finallist extends AppCompatActivity {

    ListView listView;

    MainDB db;
    HodResponse hodResponse;
    HodResAdapter ad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finallist);
        listView=findViewById(R.id.finallist);

        db = new MainDB(this);
        ShowList();


    }
    private void ShowList(){
        final ArrayList<HodResponse> data = new ArrayList<>(db.getvaluess());
        ad = new HodResAdapter(data,db,this);

        listView.setAdapter(ad);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                hodResponse = data.get(i);
            }
        });
    }
}