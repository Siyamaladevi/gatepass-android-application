package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.gatepasssystem.Modal.StaffHodRequest;
import com.example.gatepasssystem.Modal.StaffRequest;

public class StafftoHod extends AppCompatActivity {
    EditText com;
    String Apr[]={"Request Status","Approved","Not Approved"};
    String apv,Name,ID,Date,hodStatus,number;
    Button sub;
    MainDB db;
    Spinner approval;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staffto_hod);
        com=findViewById(R.id.com);
        approval=findViewById(R.id.apr);
        sub=findViewById(R.id.sub);
        getSpinner();
        getval();
        db=new MainDB(this);
        SharedPreferences staffsign=getSharedPreferences("staffKey",MODE_PRIVATE);
        number=staffsign.getString("mob","");

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Comment=com.getText().toString();
                if (Comment.isEmpty()){
                    Toast.makeText(StafftoHod.this, "Enter Comment", Toast.LENGTH_SHORT).show();
                }
                else{
                    if (apv.equals("Approved")){
                        Boolean checkData = db.insertStaffHodRes(new StaffHodRequest(Name,ID,Date,apv));
                        if (checkData==true) {
                            Toast.makeText(StafftoHod.this, "Submitted Successfully!", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(StafftoHod.this, "Failed", Toast.LENGTH_SHORT).show();
                        }
                    }else if (apv.equals("Not Approved")){
                        Toast.makeText(StafftoHod.this, "Staff denied the Gate Pass", Toast.LENGTH_SHORT).show();
                        staffmes();
                    }

                }

            }
        });
    }
    public void getSpinner(){
        ArrayAdapter appArr=new ArrayAdapter<>(StafftoHod.this, android.R.layout.simple_spinner_item,Apr);
        appArr.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        approval.setAdapter(appArr);

        approval.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                apv=approval.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    public void getval(){
        {
            Intent i = getIntent();
            Name = i.getStringExtra("name");
            ID=i.getStringExtra("id");
            Date=i.getStringExtra("date");
            hodStatus=i.getStringExtra("hodStatus");


        }
    }
    private void staffmes(){
        String content="Your requesting pass has been denied";
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(number, null, content, null, null);
            Toast.makeText(getApplicationContext(),"Sent",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage().toString(),Toast.LENGTH_SHORT).show();
        }
    }
}