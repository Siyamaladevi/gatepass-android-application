package com.example.gatepasssystem.Modal;

public class StaffResponse {
    String name, regNo, dept, branch, mobile, parentMob, date, comment, staffStatus, staffCom;

    public StaffResponse(){

    }

    public StaffResponse(String name, String regNo, String dept, String branch, String parmob, String date, String comment, String staffstatus, String staffcom) {
        this.name = name;
        this.regNo = regNo;
        this.dept = dept;
        this.branch = branch;
        this.parentMob = parmob;
        this.date = date;
        this.comment = comment;
        this.staffStatus = staffstatus;
        this.staffCom = staffcom;

    }

    public String getName() {
        return name;
    }

    public String getRegNo() {
        return regNo;
    }

    public String getDept() {
        return dept;
    }

    public String getBranch() {
        return branch;
    }

    public String getMobile() {
        return mobile;
    }

    public String getParentMob() {
        return parentMob;
    }

    public String getDate() {
        return date;
    }

    public String getComment() {
        return comment;
    }

    public String getStaffStatus() {
        return staffStatus;
    }

    public String getStaffCom() {
        return staffCom;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setParentMob(String parentMob) {
        this.parentMob = parentMob;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setStaffStatus(String staffStatus) {
        this.staffStatus = staffStatus;
    }

    public void setStaffCom(String staffCom) {
        this.staffCom = staffCom;
    }
}

