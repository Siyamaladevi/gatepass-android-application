package com.example.gatepasssystem.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.gatepasssystem.MainDB;
import com.example.gatepasssystem.Modal.StaffHodRequest;
import com.example.gatepasssystem.R;
import com.example.gatepasssystem.StafftoHod;
import com.example.gatepasssystem.StafftoPrin;

import java.util.ArrayList;

public class StaffHodAdapter extends ArrayAdapter<StaffHodRequest> {
    Context c;

    public StaffHodAdapter(ArrayList<StaffHodRequest> listModal , MainDB Db, Context context) {
        super(context, R.layout.stafinalview,listModal);
    }

    public class Holder{
        TextView Name,ID,HodStatus,Date;
        Button btn;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        StaffHodRequest data = getItem(position);

        final Holder viewHolder;

        if (convertView==null){

            viewHolder = new Holder();

            LayoutInflater inflater =LayoutInflater.from(getContext());
            convertView =inflater.inflate(R.layout.stafinalview,parent,false);
            viewHolder.Name=convertView.findViewById(R.id.n1);
            viewHolder.ID=convertView.findViewById(R.id.id1);
            viewHolder.HodStatus=convertView.findViewById(R.id.hs1);
            viewHolder.Date=convertView.findViewById(R.id.d1);
            viewHolder.btn=convertView.findViewById(R.id.btn);
            viewHolder.btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String name =viewHolder.Name.getText().toString();
                    String regNo=viewHolder.ID.getText().toString();
                    String date=viewHolder.Date.getText().toString();
                    String hodStatus=viewHolder.HodStatus.getText().toString();


                    Intent intent=new Intent(getContext(), StafftoPrin.class);
                    intent.putExtra("name",name);
                    intent.putExtra("id",regNo);
                    intent.putExtra("date",date);
                    intent.putExtra("hodStatus",hodStatus);
                    getContext().startActivity(intent);


                }
            });


            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (StaffHodAdapter.Holder) convertView.getTag();
        }

        viewHolder.Name.setText(data.getName());
        viewHolder.ID.setText(data.getID());
        viewHolder.Date.setText(data.getDate());
        viewHolder.HodStatus.setText(data.gethodStatus());




        return convertView;
    }
}
