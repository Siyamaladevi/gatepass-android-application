package com.example.gatepasssystem.Modal;



public class StaffPrincipalRes  {
    String name,dept,id,mob,date,com,hodSts,hodCom,pSts,pCom;

    public StaffPrincipalRes(){

    }
    public StaffPrincipalRes(String Name, String ID, String Date){
        this.name=Name;
        this.id=ID;
        this.date=Date;

    }
    public String getDate() {
        return date;
    }

    public String getDept() {
        return dept;
    }

    public String getName() {
        return name;
    }

    public String getCom() {
        return com;
    }

    public String getID() {
        return id;
    }

    public String getMob() {
        return mob;
    }

    public String getHodCom() {
        return hodCom;
    }

    public String getHodSts() {
        return hodSts;
    }

    public String getpCom() {
        return pCom;
    }

    public String getpSts() {
        return pSts;
    }

    public void setpCom(String pCom) {
        this.pCom = pCom;
    }

    public void setpSts(String pSts) {
        this.pSts = pSts;
    }

    public void setHodCom(String hodCom) {
        this.hodCom = hodCom;
    }

    public void setHodSts(String hodSts) {
        this.hodSts = hodSts;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCom(String com) {
        this.com = com;
    }

    public void setID(String id) {
        this.id = id;
    }

    public void setMob(String mob) {
        this.mob = mob;
    }
}

