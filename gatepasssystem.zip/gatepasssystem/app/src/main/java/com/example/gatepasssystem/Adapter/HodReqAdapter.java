package com.example.gatepasssystem.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.gatepasssystem.HodtoPrin;
import com.example.gatepasssystem.MainDB;
import com.example.gatepasssystem.Modal.HodRequest;
import com.example.gatepasssystem.Modal.StaffRequest;
import com.example.gatepasssystem.R;

import java.util.ArrayList;

public class HodReqAdapter extends ArrayAdapter<HodRequest> {
    Context c;

    public HodReqAdapter(ArrayList<HodRequest> listModal , MainDB Db, Context context) {
        super(context, R.layout.hlistview,listModal);
    }

    public class Holder{
        TextView Name,ID,Dept,Date,Comment,Mobile;
        Button btn;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        HodRequest data = getItem(position);

        final Holder viewHolder;

        if (convertView==null){

            viewHolder = new Holder();

            LayoutInflater inflater =LayoutInflater.from(getContext());
            convertView =inflater.inflate(R.layout.hlistview,parent,false);
            viewHolder.Name=convertView.findViewById(R.id.n1);
            viewHolder.ID=convertView.findViewById(R.id.id1);
            viewHolder.Dept=convertView.findViewById(R.id.de1);
            viewHolder.Date=convertView.findViewById(R.id.d1);
            viewHolder.Comment=convertView.findViewById(R.id.r1);
            viewHolder.Mobile=convertView.findViewById(R.id.m1);
            viewHolder.btn=convertView.findViewById(R.id.btn);
            viewHolder.btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String name =viewHolder.Name.getText().toString();
                    String id=viewHolder.ID.getText().toString();
                    String dept=viewHolder.Dept.getText().toString();
                    String date=viewHolder.Date.getText().toString();
                    String comment=viewHolder.Comment.getText().toString();
                    String mobile=viewHolder.Mobile.getText().toString();


                    Intent intent=new Intent(getContext(), HodtoPrin.class);
                    intent.putExtra("name",name);
                    intent.putExtra("id",id);
                    intent.putExtra("dept",dept);
                    intent.putExtra("date",date);
                    intent.putExtra("comment",comment);
                    intent.putExtra("mob",mobile);
                    getContext().startActivity(intent);


                }
            });


            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (Holder) convertView.getTag();
        }

        viewHolder.Name.setText(data.getName());
        viewHolder.ID.setText(data.getId());
        viewHolder.Dept.setText(data.getDept());
        viewHolder.Date.setText(data.getDate());
        viewHolder.Comment.setText(data.getCom());
        viewHolder.Mobile.setText(data.getMob());



        return convertView;
    }
}
