package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.gatepasssystem.Modal.StudentRequest;

import java.util.Calendar;

public class StudentReq extends AppCompatActivity {
    String name,regno,dept,mob,parMob,branch;
    EditText comment,Cal,date;
    ImageView calendar;
    MainDB data;
    int d,m,y;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_req);
        //place=findViewById(R.id.place);
        comment=findViewById(R.id.com);
        calendar=findViewById(R.id.cal);
        Cal=findViewById(R.id.date);
        date=findViewById(R.id.date);
        submit=findViewById(R.id.sub);
        data=new MainDB(this);

        SharedPreferences studSign=getSharedPreferences("studKey",MODE_PRIVATE);
        name=studSign.getString("name","");
        regno=studSign.getString("regNo","");
        dept=studSign.getString("dept","");
        mob=studSign.getString("mob","");
        parMob=studSign.getString("pnm","");
        branch=studSign.getString("br","");

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //String Place=place.getText().toString();
                String Date=Cal.getText().toString();
                String Comment=comment.getText().toString();

               // if (Place.isEmpty()){
                    Toast.makeText(StudentReq.this, "Enter Place", Toast.LENGTH_SHORT).show();
                if (Date.isEmpty()) {
                    Toast.makeText(StudentReq.this, "Enter Date", Toast.LENGTH_SHORT).show();

                } else if (Comment.isEmpty()) {
                    Toast.makeText(StudentReq.this, "Enter Comment", Toast.LENGTH_SHORT).show();

                }else {
                    Boolean CheckData=data.insertStuReq(new StudentRequest(name,regno,dept,branch,mob,parMob,Date,Comment));
                    if(CheckData==true) {

                        Toast.makeText(StudentReq.this, "Submitted Successfully! ", Toast.LENGTH_SHORT).show();
                    }else {
                        Toast.makeText(StudentReq.this,"failed",Toast.LENGTH_SHORT).show();
                    }

                }


            }



        });
        calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal=Calendar.getInstance();
                d=cal.get(Calendar.DAY_OF_MONTH);
                m=cal.get(Calendar.MONTH);
                y=cal.get(Calendar.YEAR);
                DatePickerDialog caldr= new DatePickerDialog(StudentReq.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        Cal.setText(i2+"/"+(i1+1)+"/"+i);
                    }
                },d,m,y);
                caldr.show();


            }
        });


    }

    private void SMS(){
        String content="Requesting gatepass from student";
        try {
            SmsManager sms = SmsManager.getDefault();
         //   sms.sendTextMessage(number, null, content, null, null);
            Toast.makeText(getApplicationContext(),"Sent",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage().toString(),Toast.LENGTH_SHORT).show();
        }
    }
}