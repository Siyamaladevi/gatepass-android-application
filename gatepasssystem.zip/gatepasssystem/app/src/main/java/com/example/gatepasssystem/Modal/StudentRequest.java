package com.example.gatepasssystem.Modal;

public class StudentRequest {

    String name,dept,branch,reg_no,mobile,p_no,date,comment;


    public StudentRequest(){

    }

    public StudentRequest(String name,String regNo,String dept,String branch,String mobile,String parmob,String date,String comment){
        this.name=name;
        this.reg_no=regNo;
        this.dept=dept;
        this.branch=branch;
        this.mobile=mobile;
        this.p_no=parmob;
        this.date=date;
        this.comment=comment;
    }

    public String getBranch() {
        return branch;
    }

    public String getComment() {
        return comment;
    }

    public String getDate() {
        return date;
    }

    public String getDept() {
        return dept;
    }

    public String getMobile() {
        return mobile;
    }

    public String getP_no() {
        return p_no;
    }

    public String getName() {
        return name;
    }

    public String getReg_no() {
        return reg_no;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setP_no(String p_no) {
        this.p_no = p_no;
    }

    public void setReg_no(String reg_no) {
        this.reg_no = reg_no;
    }
}
