package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class StaffSignup extends AppCompatActivity {
    EditText name,dept,mob,pass,id;
    RadioGroup button;
    RadioButton  staffHod;
    MainDB data;
    Button submit;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staffsignup);
        name=findViewById(R.id.name);
        dept=findViewById(R.id.dept);
        mob=findViewById(R.id.mobl);
        pass=findViewById(R.id.pword);
        id=findViewById(R.id.id);
        button=findViewById(R.id.button);
        submit=findViewById(R.id.st);
        data=new MainDB(this);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int SelectStaff=button.getCheckedRadioButtonId();
                staffHod= findViewById(SelectStaff);
                String Name=name.getText().toString();
                String Department=dept.getText().toString();
                String ID=id.getText().toString();
                String Mobile=mob.getText().toString();
                String Password=pass.getText().toString();

                String BTN=staffHod.getText().toString();
                if (Name.isEmpty()){
                    Toast.makeText(StaffSignup.this, "Enter Name", Toast.LENGTH_SHORT).show();
                } else if (Department.isEmpty()) {
                    Toast.makeText(StaffSignup.this,"Enter Department",Toast.LENGTH_SHORT).show();
                }
                else if (ID.isEmpty()) {
                    Toast.makeText(StaffSignup.this,"Enter StaffID",Toast.LENGTH_SHORT).show();
                }else if (Mobile.isEmpty()) {
                    Toast.makeText(StaffSignup.this,"Enter Mobile Number",Toast.LENGTH_SHORT).show();

                } else if (Password.isEmpty()) {
                    Toast.makeText(StaffSignup.this,"Enter password",Toast.LENGTH_SHORT).show();
                }

                else if(BTN.equals("Staff")){

                    SharedPreferences staffsign=getSharedPreferences("staffKey",MODE_PRIVATE);
                    SharedPreferences.Editor editor=staffsign.edit();
                    editor.putString("name",Name);
                    editor.putString("dept",Department);
                    editor.putString("mob",Mobile);
                    editor.putString("id",ID);
                    editor.apply();
                    Boolean checkstaffid=data.checkstaffname(ID);
                    if (checkstaffid==false) {
                        Boolean b = data.insertStaff(Name, Department, ID, Mobile, Password);
                        if (b == true) {

                            Toast.makeText(StaffSignup.this, "Signup Successfully!", Toast.LENGTH_SHORT).show();
                            Intent StaffSign = new Intent(StaffSignup.this, StaffLogin.class);
                            startActivity(StaffSign);
                        } else {
                            Toast.makeText(StaffSignup.this, "Staff Register Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(StaffSignup.this, "Username already exists!", Toast.LENGTH_SHORT).show();
                    }

                } else if (BTN.equals("HOD")) {

                    SharedPreferences hodsign=getSharedPreferences("hodkey",MODE_PRIVATE);
                    SharedPreferences.Editor editor=hodsign.edit();
                    editor.putString("name",Name);
                    editor.putString("dept",Department);
                    editor.putString("mob",Mobile);
                    editor.putString("id",ID);
                    editor.apply();
                    Boolean checkdata=data.checkhodname(ID);
                    if (checkdata==false) {
                        Boolean bn = data.insertHod(Name, Department, ID, Mobile, Password);
                        if (bn == true) {

                            Toast.makeText(StaffSignup.this, "Signup Successfully!", Toast.LENGTH_SHORT).show();
                            Intent StaffSign = new Intent(StaffSignup.this, StaffLogin.class);
                            startActivity(StaffSign);
                        } else {
                            Toast.makeText(StaffSignup.this, "Hod Register Failed", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(StaffSignup.this, "Username already exists!", Toast.LENGTH_SHORT).show();
                    }

                }else {
                    Toast.makeText(StaffSignup.this, "Failed", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }
}