package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    CardView Student,Staff,Security,Principal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Student=findViewById(R.id.stud);
        Staff=findViewById(R.id.staff);
        Security=findViewById(R.id.security);
        Principal=findViewById(R.id.principal);



        Student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent stud=new Intent(MainActivity.this, StudentLogin.class);
                startActivity(stud);

            }
        });
        Staff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent staff= new Intent(MainActivity.this, StaffLogin.class);
                startActivity(staff);

            }
        });

        Security.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent security=new Intent(MainActivity.this, SecurityLoin.class);
                startActivity(security);

            }
        });
        Principal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent principal=new Intent(MainActivity.this, PrincipalLogin.class);
                startActivity(principal);

            }
        });





    }
}