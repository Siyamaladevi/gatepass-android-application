package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SecurityDashboard extends AppCompatActivity {
    CardView stulist, stafflist,hod;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_securitdashboard);
        stulist = findViewById(R.id.stuList);
        stafflist = findViewById(R.id.stafflist);
        hod=findViewById(R.id.hodlist);


        stulist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SecurityDashboard.this, Finallist.class);
                startActivity(intent);
            }
        });
        stafflist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(SecurityDashboard.this,StoPFinal.class);
                startActivity(i);
            }
        });
        hod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(SecurityDashboard.this,HPRes.class);
                startActivity(i);
            }
        });
    }
}