package com.example.gatepasssystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SecurityLoin extends AppCompatActivity {
    EditText username,password;

    Button submit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_securityloin);
        username=findViewById(R.id.user);
        password=findViewById(R.id.pass);
        submit=findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Username=username.getText().toString();
                String Password=password.getText().toString();

                if (Username.isEmpty()){
                    Toast.makeText(SecurityLoin.this,"Enter Username",Toast.LENGTH_SHORT).show();
                } else if (Password.isEmpty()) {
                    Toast.makeText(SecurityLoin.this,"Enter Password",Toast.LENGTH_SHORT).show();

                }
                else if (Username.equals("pass")&& Password.equals("123")) {
                    Toast.makeText(SecurityLoin.this,"Login successfully!",Toast.LENGTH_SHORT).show();

                    Intent stud= new Intent(SecurityLoin.this, SecurityDashboard.class);
                    startActivity(stud);
                }
                else {
                    Toast.makeText(SecurityLoin.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }


            }
        });

    }
}